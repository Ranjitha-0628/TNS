package com.tnsif.project.myproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tnsif.project.myproject.entity.Employee;
import com.tnsif.project.myproject.repository.EmployeeRepo;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    // Add Employee
    public Employee addEmployee(Employee employee) {
        return employeeRepo.save(employee);
    }

    // Get all Employees
    public List<Employee> getAllEmployees() {
        return employeeRepo.findAll();
    }

    // Delete Employee by ID
    public void deleteEmployee(Long id) {
        employeeRepo.deleteById(id);
    }

    // Update Employee
    public Employee updateEmployee(Employee employee) {
        Employee existingEmployee = employeeRepo.findById(employee.getId()).orElse(null);
        if (existingEmployee != null) {
            existingEmployee.setName(employee.getName());
            existingEmployee.setEmail(employee.getEmail());
            existingEmployee.setDepartment(employee.getDepartment());
            existingEmployee.setSalary(employee.getSalary());
            return employeeRepo.save(existingEmployee);
        }
        return null; // or throw exception if not found
    }

    // Check if Employee exists
    public boolean existsById(Long id) {
        return employeeRepo.existsById(id);
    }
}
